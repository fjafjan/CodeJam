print "foobar"
